document.addEventListener('DOMContentLoaded', () => {
    // Initialize elements
    const createFolderBtn = document.getElementById('createFolder');
    const uploadForm = document.getElementById('uploadForm');
    const logoutButton = document.getElementById('logoutButton');
    const editProfileBtn = document.getElementById('editProfileBtn');
    const editProfileForm = document.getElementById('editProfileForm');
    const cancelEditBtn = document.getElementById('cancelEdit');

    // Registration form handling
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            
            const formData = new FormData();
            formData.append('username', document.getElementById('registerUsername').value);
            formData.append('phone', document.getElementById('registerPhone').value);
            formData.append('password', document.getElementById('registerPassword').value);
            
            const photoFile = document.getElementById('registerPhoto').files[0];
            if (!photoFile) {
                alert('Please select a profile picture');
                return;
            }
            formData.append('photo', photoFile);

            try {
                const response = await fetch('http://127.0.0.1:5000/api/register', {
                    method: 'POST',
                    body: formData // Send as FormData, not JSON
                });

                const data = await response.json();
                
                if (response.ok) {
                    localStorage.setItem('user', JSON.stringify({
                        id: data.user_id,
                        username: data.username,
                        phone: document.getElementById('registerPhone').value,
                        photo_filename: data.photo_filename
                    }));
                    alert('Registration successful!');
                    window.location.href = 'profile.html';
                } else {
                    alert(`Registration failed: ${data.error}`);
                }
            } catch (error) {
                console.error('Registration error:', error);
                alert('Registration failed. Please try again.');
            }
        });
    }

    // Sign in form handling
    const signInForm = document.getElementById('signInForm');
    if (signInForm) {
        signInForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const loginData = {
                phone: document.getElementById('signInPhone').value,
                password: document.getElementById('signInPassword').value
            };

            try {
                const response = await fetch('http://127.0.0.1:5000/api/signin', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(loginData)
                });

                const data = await response.json();
                console.log('Sign in response:', data);
                
                if (response.ok) {
                    const userData = {
                        id: data.user_id,
                        username: data.username,
                        phone: loginData.phone,
                        photo_filename: data.photo_filename  // Store filename instead of path
                    };
                    console.log('Storing user data:', userData);
                    localStorage.setItem('user', JSON.stringify(userData));
                    
                    alert('Sign in successful!');
                    window.location.href = 'profile.html';
                } else {
                    alert(`Sign in failed: ${data.error}`);
                }
            } catch (error) {
                console.error('Login error:', error);
                alert('Sign in failed. Please try again.');
            }
        });
    }

    // Handle folder creation
    if (createFolderBtn) {
        createFolderBtn.addEventListener('click', () => {
            const eventName = document.getElementById('eventName').value;
            if (eventName) {
                const folderList = document.getElementById('folders');
                const folderItem = document.createElement('div');
                folderItem.className = 'folder-item';
                folderItem.textContent = eventName;
                folderItem.addEventListener('click', () => {
                    document.querySelectorAll('.folder-item').forEach(item => 
                        item.classList.remove('selected'));
                    folderItem.classList.add('selected');
                });
                folderList.appendChild(folderItem);
                document.getElementById('eventName').value = '';
            }
        });
    }

    // Handle photo uploads
    if (uploadForm) {
        uploadForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            
            // Get the current event details
            const eventDetails = JSON.parse(localStorage.getItem('currentEvent'));
            if (!eventDetails) {
                alert('Please create an event first');
                return;
            }

            const files = document.getElementById('photoInput').files;
            if (files.length === 0) {
                alert('Please select photos to upload');
                return;
            }

            const formData = new FormData();
            // Add event details to formData
            formData.append('eventName', eventDetails.name);
            formData.append('eventDate', eventDetails.date);
            formData.append('eventDescription', eventDetails.description);

            // Add all selected photos
            for (let i = 0; i < files.length; i++) {
                formData.append('photos', files[i]);
            }

            try {
                const uploadStatus = document.getElementById('uploadStatus');
                const uploadProgress = document.getElementById('uploadProgress');
                uploadProgress.classList.remove('hidden');

                const response = await fetch('http://127.0.0.1:5000/api/upload_photos', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                
                if (response.ok) {
                    uploadStatus.innerHTML = `<div class="success">Successfully uploaded ${files.length} photos to event: ${eventDetails.name}</div>`;
                    // Clear the file input and preview
                    document.getElementById('photoInput').value = '';
                    document.getElementById('imagePreview').innerHTML = '';
                } else {
                    uploadStatus.innerHTML = `<div class="error">Upload failed: ${data.error}</div>`;
                }
            } catch (error) {
                console.error('Upload error:', error);
                document.getElementById('uploadStatus').innerHTML = 
                    `<div class="error">Error uploading photos: ${error.message}</div>`;
            } finally {
                uploadProgress.classList.add('hidden');
            }
        });
    }

    // Handle file input change for preview
    const photoInput = document.getElementById('photoInput');
    if (photoInput) {
        photoInput.addEventListener('change', (e) => {
            const imagePreview = document.getElementById('imagePreview');
            imagePreview.innerHTML = '';
            
            [...e.target.files].forEach(file => {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'preview-image';
                    imagePreview.appendChild(img);
                };
                reader.readAsDataURL(file);
            });
        });
    }

    // Handle profile editing
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', () => {
            document.getElementById('editName').value = document.getElementById('userName').textContent;
            document.getElementById('editPhone').value = document.getElementById('userPhone').textContent.replace(/\D/g, '');
            editProfileForm.classList.remove('hidden');
        });
    }

    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', () => {
            editProfileForm.classList.add('hidden');
        });
    }

    if (editProfileForm) {
        editProfileForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            
            const userDataString = localStorage.getItem('user');
            if (!userDataString) {
                alert('Please sign in again');
                window.location.href = 'login.html';
                return;
            }

            const userData = JSON.parse(userDataString);
            const updateData = {
                user_id: userData.id,
                username: document.getElementById('editName').value,
                phone: document.getElementById('editPhone').value
            };

            try {
                const response = await fetch('http://127.0.0.1:5000/api/update_profile', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(updateData)
                });

                const data = await response.json();
                if (response.ok) {
                    // Update localStorage with new data
                    userData.username = updateData.username;
                    userData.phone = updateData.phone;
                    localStorage.setItem('user', JSON.stringify(userData));

                    // Update display
                    document.getElementById('userName').textContent = updateData.username;
                    document.getElementById('userPhone').textContent = formatPhoneNumber(updateData.phone);
                    editProfileForm.classList.add('hidden');
                    alert('Profile updated successfully!');
                } else {
                    alert(`Update failed: ${data.error}`);
                }
            } catch (error) {
                console.error('Update error:', error);
                alert('Profile update failed. Please try again.');
            }
        });
    }

    // Handle logout
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            localStorage.removeItem('user');
            window.location.href = '../index.html';
        });
    }

    // Load photos in gallery if on photos page
    const photoGrid = document.getElementById('photoGrid');
    if (photoGrid) {
        loadPhotos();
    }

    // Function to load photos
    async function loadPhotos(folder = 'default') {
        try {
            const response = await fetch(`http://127.0.0.1:5000/api/photos/${folder}`);
            const photos = await response.json();
            
            photoGrid.innerHTML = '';
            photos.forEach(photo => {
                const photoCard = createPhotoCard(photo);
                photoGrid.appendChild(photoCard);
            });
        } catch (error) {
            console.error('Error loading photos:', error);
        }
    }

    // Function to create photo card
    function createPhotoCard(photo) {
        const div = document.createElement('div');
        div.className = 'photo-card';
        
        // Create thumbnail container
        div.innerHTML = `
            <div class="thumbnail">
                <img src="http://127.0.0.1:5000/api/photo/${photo.filename}" 
                     alt="Event photo" 
                     loading="lazy">
            </div>
            <div class="photo-actions">
                <button class="action-btn view-btn" title="View">
                    <i class="fas fa-expand"></i>
                </button>
                <button class="action-btn download-btn" title="Download">
                    <i class="fas fa-download"></i>
                </button>
            </div>
        `;

        // Add click handler for full-size view
        div.querySelector('.view-btn').addEventListener('click', () => {
            openPhotoViewer(photo);
        });

        // Add download handler
        div.querySelector('.download-btn').addEventListener('click', () => {
            downloadPhoto(photo.filename);
        });

        return div;
    }

    function openPhotoViewer(photo) {
        const viewer = document.createElement('div');
        viewer.className = 'photo-viewer';
        viewer.innerHTML = `
            <div class="photo-viewer-content">
                <span class="close-viewer">&times;</span>
                <img src="http://127.0.0.1:5000/api/photo/${photo.filename}" 
                     alt="Full size photo">
            </div>
        `;

        // Close viewer when clicking the X or outside the image
        viewer.addEventListener('click', (e) => {
            if (e.target === viewer || e.target.classList.contains('close-viewer')) {
                viewer.remove();
            }
        });

        document.body.appendChild(viewer);
    }

    // Load user profile data if on profile page
    if (window.location.pathname.includes('profile.html')) {
        loadUserProfile();
    }

    // Add this after your DOMContentLoaded event listener
    const registerPhoto = document.getElementById('registerPhoto');
    if (registerPhoto) {
        registerPhoto.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('registerPhotoPreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // Add this to your existing DOMContentLoaded event listener
    const createEventBtn = document.getElementById('createEventBtn');
    const changeEventBtn = document.getElementById('changeEventBtn');
    const createEventSection = document.getElementById('createEventSection');
    const uploadPhotosSection = document.getElementById('uploadPhotosSection');

    if (createEventBtn) {
        createEventBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const eventName = document.getElementById('eventName').value;
            const eventDate = document.getElementById('eventDate').value;
            
            if (!eventName || !eventDate) {
                alert('Please fill in the event name and date');
                return;
            }

            // Store event details
            const eventDetails = {
                name: eventName,
                date: eventDate,
                description: document.getElementById('eventDescription').value
            };
            localStorage.setItem('currentEvent', JSON.stringify(eventDetails));

            // Update UI
            document.getElementById('currentEventName').textContent = eventName;
            createEventSection.style.display = 'none';
            uploadPhotosSection.style.display = 'block';
        });
    }

    if (changeEventBtn) {
        changeEventBtn.addEventListener('click', () => {
            createEventSection.style.display = 'block';
            uploadPhotosSection.style.display = 'none';
        });
    }

    // Add these functions to your main.js
    function loadEventFolders() {
        const eventFoldersList = document.getElementById('eventFoldersList');
        if (!eventFoldersList) return;

        fetch('http://127.0.0.1:5000/api/events')
            .then(response => response.json())
            .then(events => {
                console.log('Loaded events:', events); // Debug log
                eventFoldersList.innerHTML = '';
                if (events && events.length > 0) {
                    events.forEach(event => {
                        const folderCard = createFolderCard(event);
                        eventFoldersList.appendChild(folderCard);
                    });
                } else {
                    eventFoldersList.innerHTML = '<p class="no-events">No events found</p>';
                }
            })
            .catch(error => {
                console.error('Error loading events:', error);
                eventFoldersList.innerHTML = '<p class="error">Error loading events</p>';
            });
    }

    function createFolderCard(event) {
        const div = document.createElement('div');
        div.className = 'folder-card';
        div.innerHTML = `
            <div class="folder-content">
                <i class="fas fa-folder folder-icon"></i>
                <h3 class="folder-name">${event.name}</h3>
                <p class="folder-date">${new Date(event.date).toLocaleDateString()}</p>
                <p class="photo-count">${event.photo_count} photos</p>
            </div>
            <div class="folder-actions">
                <button class="action-btn view-btn" title="View Photos">
                    <i class="fas fa-images"></i>
                </button>
                <button class="action-btn delete-btn" title="Delete Folder">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        // Add click handlers
        div.querySelector('.view-btn').addEventListener('click', () => openFolderModal(event));
        div.querySelector('.delete-btn').addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent folder modal from opening
            deleteFolder(event.name);
        });
        
        return div;
    }

    function openFolderModal(event) {
        const modal = document.getElementById('folderModal');
        const modalEventName = document.getElementById('modalEventName');
        const photosGrid = document.getElementById('eventPhotosGrid');
        
        modalEventName.textContent = event.name;
        modal.style.display = 'block';
        
        // Load photos for this event
        fetch(`http://127.0.0.1:5000/api/event_photos/${event.name}`)
            .then(response => response.json())
            .then(photos => {
                photosGrid.innerHTML = '';
                photos.forEach(photo => {
                    const photoCard = createPhotoCard(photo);
                    photosGrid.appendChild(photoCard);
                });
            })
            .catch(error => console.error('Error loading photos:', error));
    }

    // Add modal close functionality
    document.querySelector('.close-modal')?.addEventListener('click', () => {
        document.getElementById('folderModal').style.display = 'none';
    });

    // Load folders when the page loads
    if (document.getElementById('eventFoldersSection')) {
        loadEventFolders();
    }
});

// Global functions for photo actions
function downloadPhoto(path) {
    window.open(`http://127.0.0.1:5000${path}`, '_blank');
}

function deletePhoto(path) {
    if (confirm('Are you sure you want to delete this photo?')) {
        console.log('Deleting photo:', path);
        // Implement delete functionality
    }
}

// Add this function to load user profile data
function loadUserProfile() {
    const userDataString = localStorage.getItem('user');
    console.log('Loading user profile, user data:', userDataString);

    const authSection = document.getElementById('authSection');
    const profileSection = document.getElementById('profileSection');

    if (userDataString) {
        const userData = JSON.parse(userDataString);
        console.log('Parsed user data:', userData);
        
        // Update profile elements
        const userNameElement = document.getElementById('userName');
        const userPhoneElement = document.getElementById('userPhone');
        const profilePhotoElement = document.getElementById('profilePhoto');
        
        if (userNameElement) {
            userNameElement.textContent = userData.username;
        }
        if (userPhoneElement) {
            userPhoneElement.textContent = formatPhoneNumber(userData.phone);
        }
        if (profilePhotoElement) {
            console.log('Found profile photo element');
            if (userData.photo_filename) {
                // Use the new profile photo endpoint
                const photoUrl = `http://127.0.0.1:5000/api/profile-photo/${userData.photo_filename}`;
                console.log('Setting profile photo URL:', photoUrl);
                
                profilePhotoElement.onerror = function() {
                    console.error('Failed to load profile photo');
                    this.src = '../images/default-profile.png';
                };
                
                profilePhotoElement.onload = function() {
                    console.log('Profile photo loaded successfully');
                };
                
                profilePhotoElement.src = photoUrl;
            } else {
                console.log('No photo filename available');
                profilePhotoElement.src = '../images/default-profile.png';
            }
        }

        if (authSection) authSection.style.display = 'none';
        if (profileSection) profileSection.style.display = 'block';
    } else {
        if (authSection) authSection.style.display = 'block';
        if (profileSection) profileSection.style.display = 'none';
    }
}

// Helper function to format phone number
function formatPhoneNumber(phone) {
    return `+1 ${phone.slice(0,3)} ${phone.slice(3,6)} ${phone.slice(6)}`;
}

async function deleteFolder(folderName) {
    if (!confirm(`Are you sure you want to delete the folder "${folderName}" and all its photos?`)) {
        return;
    }

    try {
        console.log('Attempting to delete folder:', folderName); // Debug log
        const response = await fetch(`http://127.0.0.1:5000/api/folder/${encodeURIComponent(folderName)}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        console.log('Delete response:', response); // Debug log
        const data = await response.json();
        console.log('Delete response data:', data); // Debug log

        if (response.ok) {
            // Close the modal if it's open
            const modal = document.getElementById('folderModal');
            if (modal) {
                modal.style.display = 'none';
            }

            // Refresh the folders list
            loadEventFolders();
            
            // Show success message
            if (data.errors && data.errors.length > 0) {
                alert(`Folder deleted with some issues:\n${data.errors.join('\n')}`);
            } else {
                alert(`Successfully deleted folder "${folderName}" and ${data.deleted_count} photos`);
            }
        } else {
            throw new Error(data.error || 'Failed to delete folder');
        }
    } catch (error) {
        console.error('Error deleting folder:', error);
        alert(`Error deleting folder: ${error.message}`);
    }
}
