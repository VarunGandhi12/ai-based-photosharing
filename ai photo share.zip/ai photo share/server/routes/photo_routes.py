from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
import os

photo_routes = Blueprint('photo_routes', __name__)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@photo_routes.route('/upload', methods=['POST'])
def upload_photo():
    if 'photo' not in request.files:
        return jsonify({'error': 'No photo provided'}), 400

    photo = request.files['photo']
    if not allowed_file(photo.filename):
        return jsonify({'error': 'Invalid file type'}), 400

    filename = secure_filename(photo.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    photo.save(filepath)

    # Process metadata (e.g., tags, album)
    tags = request.form.get('tags', '').split(',')
    album = request.form.get('album', 'default')

    return jsonify({'message': 'Photo uploaded successfully!', 'tags': tags, 'album': album, 'file': filepath}), 200
