from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from pymongo import MongoClient
import os
import datetime
from flask_bcrypt import Bcrypt
import logging

app = Flask(__name__)
bcrypt = Bcrypt(app)
CORS(app, supports_credentials=True)  # Simplified CORS setup

# Configuration
UPLOAD_FOLDER = os.path.abspath('uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create upload folder if it doesn't exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Update the MongoDB configuration section
try:
    # MongoDB setup with error handling
    client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=5000)
    # Test the connection
    client.server_info()
    db = client['photo_share']
    users_collection = db['users']
    photos_collection = db['photos']
    print("Successfully connected to MongoDB")
except Exception as e:
    print(f"Error connecting to MongoDB: {e}")
    raise Exception("Failed to connect to MongoDB. Make sure MongoDB is running.")

# Create indexes for better query performance
try:
    users_collection.create_index([('phone', 1)], unique=True)
    photos_collection.create_index([('user_id', 1)])
    photos_collection.create_index([('folder', 1)])
except Exception as e:
    print(f"Error creating indexes: {e}")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Authentication routes
@app.route('/api/register', methods=['POST'])
def register():
    try:
        username = request.form.get('username')
        phone = request.form.get('phone')
        password = request.form.get('password')
        photo = request.files.get('photo')

        if not all([username, phone, password, photo]):
            return jsonify({'error': 'Missing required fields'}), 400

        if not phone.isdigit() or len(phone) != 10:
            return jsonify({'error': 'Invalid phone number format'}), 400

        if users_collection.find_one({'phone': phone}):
            return jsonify({'error': 'Phone number already registered'}), 400

        if photo and allowed_file(photo.filename):
            filename = secure_filename(f"profile_{phone}_{photo.filename}")
            photo_path = os.path.join(UPLOAD_FOLDER, 'profile_photos', filename)
            os.makedirs(os.path.dirname(photo_path), exist_ok=True)
            photo.save(photo_path)
        else:
            return jsonify({'error': 'Invalid photo format'}), 400

        user_data = {
            'username': username,
            'phone': phone,
            'password': bcrypt.generate_password_hash(password).decode('utf-8'),
            'photo_filename': filename,
            'created_at': datetime.datetime.now()
        }
        
        result = users_collection.insert_one(user_data)
        
        return jsonify({
            'message': 'Registration successful',
            'user_id': str(result.inserted_id),
            'username': username
        }), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/signin', methods=['POST'])
def signin():
    try:
        data = request.get_json()
        phone = data.get('phone')
        password = data.get('password')

        if not phone or not password:
            return jsonify({'error': 'Phone and password are required'}), 400

        user = users_collection.find_one({'phone': phone})
        if user and bcrypt.check_password_hash(user['password'], password):
            return jsonify({
                'message': 'Sign in successful',
                'user_id': str(user['_id']),
                'username': user['username']
            }), 200
        return jsonify({'error': 'Invalid phone number or password'}), 401

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Photo management routes
@app.route('/api/upload', methods=['POST', 'OPTIONS'])
def upload_photos():
    # Handle CORS preflight
    if request.method == 'OPTIONS':
        response = jsonify({'status': 'ok'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response

    try:
        print("Received files:", request.files)  # Debug print
        print("Received form data:", request.form)  # Debug print

        if 'photos' not in request.files:
            return jsonify({'error': 'No files provided'}), 400

        files = request.files.getlist('photos')
        event_folder = request.form.get('folder', 'default')
        user_id = request.form.get('user_id')
        username = request.form.get('username')

        if not user_id or not username:
            return jsonify({'error': 'User ID and username required'}), 400

        # Create absolute path for uploads
        UPLOAD_FOLDER = os.path.abspath(os.path.join(os.getcwd(), 'uploads'))
        print("Upload folder path:", UPLOAD_FOLDER)  # Debug print

        # Create main uploads directory
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)

        # Create user-specific directory
        user_folder = os.path.join(UPLOAD_FOLDER, username)
        os.makedirs(user_folder, exist_ok=True)

        # Create event folder
        event_path = os.path.join(user_folder, event_folder)
        os.makedirs(event_path, exist_ok=True)

        uploaded_files = []
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                new_filename = f"{timestamp}_{filename}"
                file_path = os.path.join(event_path, new_filename)
                
                print(f"Saving file to: {file_path}")  # Debug print
                file.save(file_path)

                relative_path = f'{username}/{event_folder}/{new_filename}'
                uploaded_files.append({
                    'filename': new_filename,
                    'path': f'/uploads/{relative_path}'
                })

                # Save to database
                photos_collection.insert_one({
                    'user_id': user_id,
                    'username': username,
                    'filename': new_filename,
                    'folder': event_folder,
                    'path': f'/uploads/{relative_path}',
                    'uploaded_at': datetime.datetime.now()
                })

        response = jsonify({
            'message': 'Upload successful',
            'files': uploaded_files
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 200

    except Exception as e:
        print(f"Upload error: {str(e)}")  # Debug print
        return jsonify({'error': str(e)}), 500

@app.route('/api/photos', methods=['GET'])
def get_user_photos():
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'error': 'User ID required'}), 400

        photos = list(photos_collection.find({'user_id': user_id}))
        for photo in photos:
            photo['_id'] = str(photo['_id'])

        return jsonify(photos), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/photos/<folder>', methods=['GET'])
def get_folder_photos(folder):
    try:
        photos = list(photos_collection.find({'folder': folder}))
        for photo in photos:
            photo['_id'] = str(photo['_id'])

        return jsonify(photos), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# File serving routes
@app.route('/uploads/<path:filename>')
def serve_upload(filename):
    try:
        return send_from_directory(UPLOAD_FOLDER, filename)
    except Exception as e:
        return jsonify({'error': 'File not found'}), 404

@app.route('/')
def serve_index():
    return send_from_directory('../public', 'index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory('../public', filename)

if __name__ == '__main__':
    app.run(debug=True, port=5000) 